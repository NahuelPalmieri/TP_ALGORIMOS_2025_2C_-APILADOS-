#include <stdio.h>
#include <stdlib.h>
#include "servidor_lib.h"

int main()
{
    run_server();
    return 0;
}
